# BB Bullseye Bandits GE – kostenlose PWA V1

Enthalten:
- Live-Tabelle mit den 20 Startspielern
- Ergebnisse
- Statistiken
- Punkteregeln
- Adminbereich mit Demo-PIN `1234`
- Ergebniseingabe inkl. Legs, Average, 180er, High Finish
- Spieler hinzufügen/entfernen
- Speicherung aktuell per localStorage (nur auf dem jeweiligen Gerät)
- PWA-Manifest + Service Worker

## Kostenlos veröffentlichen
Die Dateien können direkt in ein öffentliches GitHub-Repository geladen und mit GitHub Pages veröffentlicht werden.

Wichtig: Der aktuelle Admin-PIN ist nur für den Prototyp. Für eine echte Liga muss die Anmeldung serverseitig über eine Datenbank/Auth abgesichert werden.

## Nächster technischer Schritt
Supabase als kostenloses Backend anbinden: Spieler, Matches, Saisons, Admin-Login und Live-Daten werden dann zentral gespeichert. Die Supabase-Free-Stufe bietet aktuell ein kostenloses Projektkontingent und 500 MB Datenbank pro Projekt.
